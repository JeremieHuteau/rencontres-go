<DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8" />
      <link rel="stylesheet" type="text/css" href="style.php">
      <title>Rencontres-go</title>
    </head>
    <body>
      <main>
        <?php include_once 'header.php';?>
        <div id="div_Partie">
          <p>
            Chat
          </p>
        </div>
        <div id="div_Partie">
          <p>
            Goban
          </p>
        </div>
        <div id="div_Partie">
          <p>
            Chrono + derniers coups joués
          </p>
        </div>
        <footer>
          <p>Projet Développement d'applications web - Université de Bourgogne - Groupe 2</p>
        </footer>
      </main>
    </body>
  </html>
