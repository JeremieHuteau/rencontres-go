var x ;
var y ;
var coup;
function gestionClick(choix) //Choix contient l'id de la case cochée
{
	alert(choix);
	if(isPossible(choix))
	{
		insertSQL(choix);
		coup=attenteSQL();
		actualiseGrille(coup);
		coup=attenteSQL();
		actualiseGrille(coup);
	}
}
function isPossible(choix) //Vérifie la possibilité de poser le pion return true or false
{
	if (choix=="passer")
	{
		return true;
	}
	else
	{		
		parse(choix)
		if(isOeil(x,y)){
			alert("Coup impossible : positionde pion interdite"); //suicide
			return false;
		}
		else
		{
			plat[x][y] = coul ;
			newPlateau(plat);
			if (comp(plat,prevplat))
			{
				alert("Coup impossible : retour à l'état pécédent"); // ko
				return false;
			}
			else
			{
				alert("plop");
				return true;
			}			
		}		
	}
	
}
function insertSQL(choix) //Insert le coup dans la base de donnée
{

}
function attenteSQL() // Désactive la souris en attendant l'actualisation de la base de donnée return le coup de la BD
{

}
function actualiseGrille(coup) //Actualise la Grille en fonction de coup
{

}
function newPlateau(p) // Applique les prises si besoin au plateau p
{

}
function isOeil(x,y) // Vérifie si la position est un oeil
{
	return false;
}
function comp(p1,p2) //compare deux tableau
{
	var res = true;
	for (var j = p1.length - 1; j > 0; j--) {
		for (var i = p1[j].length ; i > 0; i--) {
			res=res&&(p1[j][i]==p2[j][i]);
		};
	};
		
}
function parse(choix) //Transforme choix en coordonnée X et Y 
{
	var parseTab = choix.split('-');
	y = parseTab[0];
	x = parseTab[1];
}
